<?php
# PackageStates.php

# This file is maintained by Flow's package management. You shouldn't edit it manually
# manually, you should rather use the command line commands for maintaining packages.
# You'll find detailed information about the neos.flow:package:* commands in their
# respective help screens.

# This file will be regenerated automatically if it doesn't exist. Deleting this file
# should, however, never become necessary if you use the package commands.

return array (
  'packages' => 
  array (
    'psr/simple-cache' => 
    array (
      'packageKey' => 'psr.simplecache',
      'packagePath' => 'Libraries/psr/simple-cache/',
      'composerName' => 'psr/simple-cache',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\SimpleCache\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'psr/cache' => 
    array (
      'packageKey' => 'psr.cache',
      'packagePath' => 'Libraries/psr/cache/',
      'composerName' => 'psr/cache',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Cache\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/error-messages' => 
    array (
      'packageKey' => 'neos.errormessages',
      'packagePath' => 'Libraries/neos/error-messages/',
      'composerName' => 'neos/error-messages',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Error\\Messages\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-files' => 
    array (
      'packageKey' => 'Neos.Utility.Files',
      'packagePath' => 'Libraries/neos/utility-files/',
      'composerName' => 'neos/utility-files',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-pdo' => 
    array (
      'packageKey' => 'Neos.Utility.Pdo',
      'packagePath' => 'Libraries/neos/utility-pdo/',
      'composerName' => 'neos/utility-pdo',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-opcodecache' => 
    array (
      'packageKey' => 'Neos.Utility.OpcodeCache',
      'packagePath' => 'Libraries/neos/utility-opcodecache/',
      'composerName' => 'neos/utility-opcodecache',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/cache' => 
    array (
      'packageKey' => 'Neos.Cache',
      'packagePath' => 'Libraries/neos/cache/',
      'composerName' => 'neos/cache',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Cache\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-unicode' => 
    array (
      'packageKey' => 'neos.utilityunicode',
      'packagePath' => 'Libraries/neos/utility-unicode/',
      'composerName' => 'neos/utility-unicode',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\Unicode\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-objecthandling' => 
    array (
      'packageKey' => 'Neos.Utility.ObjectHandling',
      'packagePath' => 'Libraries/neos/utility-objecthandling/',
      'composerName' => 'neos/utility-objecthandling',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-arrays' => 
    array (
      'packageKey' => 'Neos.Utility.Arrays',
      'packagePath' => 'Libraries/neos/utility-arrays/',
      'composerName' => 'neos/utility-arrays',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-mediatypes' => 
    array (
      'packageKey' => 'Neos.Utility.MediaTypes',
      'packagePath' => 'Libraries/neos/utility-mediatypes/',
      'composerName' => 'neos/utility-mediatypes',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/utility-schema' => 
    array (
      'packageKey' => 'Neos.Utility.Schema',
      'packagePath' => 'Libraries/neos/utility-schema/',
      'composerName' => 'neos/utility-schema',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Utility\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'psr/log' => 
    array (
      'packageKey' => 'psr.log',
      'packagePath' => 'Libraries/psr/log/',
      'composerName' => 'psr/log',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Log\\' => 'Psr/Log/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/flow-log' => 
    array (
      'packageKey' => 'Neos.Flow.Log',
      'packagePath' => 'Libraries/neos/flow-log/',
      'composerName' => 'neos/flow-log',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Flow\\Log\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'psr/http-message' => 
    array (
      'packageKey' => 'psr.httpmessage',
      'packagePath' => 'Libraries/psr/http-message/',
      'composerName' => 'psr/http-message',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Http\\Message\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'psr/http-factory' => 
    array (
      'packageKey' => 'psr.httpfactory',
      'packagePath' => 'Libraries/psr/http-factory/',
      'composerName' => 'psr/http-factory',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Http\\Message\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'ralouphie/getallheaders' => 
    array (
      'packageKey' => 'ralouphie.getallheaders',
      'packagePath' => 'Libraries/ralouphie/getallheaders/',
      'composerName' => 'ralouphie/getallheaders',
      'autoloadConfiguration' => 
      array (
        'files' => 
        array (
          0 => 'src/getallheaders.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'guzzlehttp/psr7' => 
    array (
      'packageKey' => 'guzzlehttp.psr7',
      'packagePath' => 'Libraries/guzzlehttp/psr7/',
      'composerName' => 'guzzlehttp/psr7',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'GuzzleHttp\\Psr7\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/functions_include.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/http-factories' => 
    array (
      'packageKey' => 'Neos.Http.Factories',
      'packagePath' => 'Framework/Neos.Http.Factories/',
      'composerName' => 'neos/http-factories',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Http\\Factories\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'psr/container' => 
    array (
      'packageKey' => 'psr.container',
      'packagePath' => 'Libraries/psr/container/',
      'composerName' => 'psr/container',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Container\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'psr/http-server-handler' => 
    array (
      'packageKey' => 'psr.httpserverhandler',
      'packagePath' => 'Libraries/psr/http-server-handler/',
      'composerName' => 'psr/http-server-handler',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Http\\Server\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'psr/http-server-middleware' => 
    array (
      'packageKey' => 'psr.httpservermiddleware',
      'packagePath' => 'Libraries/psr/http-server-middleware/',
      'composerName' => 'psr/http-server-middleware',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Http\\Server\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'brick/math' => 
    array (
      'packageKey' => 'brick.math',
      'packagePath' => 'Libraries/brick/math/',
      'composerName' => 'brick/math',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Brick\\Math\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/polyfill-php81' => 
    array (
      'packageKey' => 'symfony.polyfillphp81',
      'packagePath' => 'Libraries/symfony/polyfill-php81/',
      'composerName' => 'symfony/polyfill-php81',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Polyfill\\Php81\\' => '',
        ),
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
        'classmap' => 
        array (
          0 => 'Resources/stubs',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'ramsey/collection' => 
    array (
      'packageKey' => 'ramsey.collection',
      'packagePath' => 'Libraries/ramsey/collection/',
      'composerName' => 'ramsey/collection',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Ramsey\\Collection\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/polyfill-ctype' => 
    array (
      'packageKey' => 'symfony.polyfillctype',
      'packagePath' => 'Libraries/symfony/polyfill-ctype/',
      'composerName' => 'symfony/polyfill-ctype',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Polyfill\\Ctype\\' => '',
        ),
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/polyfill-php80' => 
    array (
      'packageKey' => 'symfony.polyfillphp80',
      'packagePath' => 'Libraries/symfony/polyfill-php80/',
      'composerName' => 'symfony/polyfill-php80',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Polyfill\\Php80\\' => '',
        ),
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
        'classmap' => 
        array (
          0 => 'Resources/stubs',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'ramsey/uuid' => 
    array (
      'packageKey' => 'ramsey.uuid',
      'packagePath' => 'Libraries/ramsey/uuid/',
      'composerName' => 'ramsey/uuid',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Ramsey\\Uuid\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/functions.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/cache' => 
    array (
      'packageKey' => 'doctrine.cache',
      'packagePath' => 'Libraries/doctrine/cache/',
      'composerName' => 'doctrine/cache',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Common\\Cache\\' => 'lib/Doctrine/Common/Cache',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/collections' => 
    array (
      'packageKey' => 'doctrine.collections',
      'packagePath' => 'Libraries/doctrine/collections/',
      'composerName' => 'doctrine/collections',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Common\\Collections\\' => 'lib/Doctrine/Common/Collections',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/event-manager' => 
    array (
      'packageKey' => 'doctrine.eventmanager',
      'packagePath' => 'Libraries/doctrine/event-manager/',
      'composerName' => 'doctrine/event-manager',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Common\\' => 'lib/Doctrine/Common',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/deprecations' => 
    array (
      'packageKey' => 'doctrine.deprecations',
      'packagePath' => 'Libraries/doctrine/deprecations/',
      'composerName' => 'doctrine/deprecations',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Deprecations\\' => 'lib/Doctrine/Deprecations',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/persistence' => 
    array (
      'packageKey' => 'doctrine.persistence',
      'packagePath' => 'Libraries/doctrine/persistence/',
      'composerName' => 'doctrine/persistence',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Common\\' => 'lib/Doctrine/Common',
          'Doctrine\\Persistence\\' => 'lib/Doctrine/Persistence',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/common' => 
    array (
      'packageKey' => 'doctrine.common',
      'packagePath' => 'Libraries/doctrine/common/',
      'composerName' => 'doctrine/common',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Common\\' => 'lib/Doctrine/Common',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/dbal' => 
    array (
      'packageKey' => 'doctrine.dbal',
      'packagePath' => 'Libraries/doctrine/dbal/',
      'composerName' => 'doctrine/dbal',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\DBAL\\' => 'lib/Doctrine/DBAL',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/inflector' => 
    array (
      'packageKey' => 'doctrine.inflector',
      'packagePath' => 'Libraries/doctrine/inflector/',
      'composerName' => 'doctrine/inflector',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Inflector\\' => 'lib/Doctrine/Inflector',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/instantiator' => 
    array (
      'packageKey' => 'doctrine.instantiator',
      'packagePath' => 'Libraries/doctrine/instantiator/',
      'composerName' => 'doctrine/instantiator',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Instantiator\\' => 'src/Doctrine/Instantiator/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/lexer' => 
    array (
      'packageKey' => 'doctrine.lexer',
      'packagePath' => 'Libraries/doctrine/lexer/',
      'composerName' => 'doctrine/lexer',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Common\\Lexer\\' => 'lib/Doctrine/Common/Lexer',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/deprecation-contracts' => 
    array (
      'packageKey' => 'symfony.deprecationcontracts',
      'packagePath' => 'Libraries/symfony/deprecation-contracts/',
      'composerName' => 'symfony/deprecation-contracts',
      'autoloadConfiguration' => 
      array (
        'files' => 
        array (
          0 => 'function.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/service-contracts' => 
    array (
      'packageKey' => 'symfony.servicecontracts',
      'packagePath' => 'Libraries/symfony/service-contracts/',
      'composerName' => 'symfony/service-contracts',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Contracts\\Service\\' => '',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/polyfill-intl-grapheme' => 
    array (
      'packageKey' => 'symfony.polyfillintlgrapheme',
      'packagePath' => 'Libraries/symfony/polyfill-intl-grapheme/',
      'composerName' => 'symfony/polyfill-intl-grapheme',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Polyfill\\Intl\\Grapheme\\' => '',
        ),
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/polyfill-intl-normalizer' => 
    array (
      'packageKey' => 'symfony.polyfillintlnormalizer',
      'packagePath' => 'Libraries/symfony/polyfill-intl-normalizer/',
      'composerName' => 'symfony/polyfill-intl-normalizer',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Polyfill\\Intl\\Normalizer\\' => '',
        ),
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
        'classmap' => 
        array (
          0 => 'Resources/stubs',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/string' => 
    array (
      'packageKey' => 'symfony.string',
      'packagePath' => 'Libraries/symfony/string/',
      'composerName' => 'symfony/string',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\String\\' => '',
        ),
        'files' => 
        array (
          0 => 'Resources/functions.php',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/console' => 
    array (
      'packageKey' => 'symfony.console',
      'packagePath' => 'Libraries/symfony/console/',
      'composerName' => 'symfony/console',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\Console\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/orm' => 
    array (
      'packageKey' => 'doctrine.orm',
      'packagePath' => 'Libraries/doctrine/orm/',
      'composerName' => 'doctrine/orm',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\ORM\\' => 'lib/Doctrine/ORM',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'laminas/laminas-code' => 
    array (
      'packageKey' => 'laminas.laminascode',
      'packagePath' => 'Libraries/laminas/laminas-code/',
      'composerName' => 'laminas/laminas-code',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Laminas\\Code\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'polyfill/ReflectionEnumPolyfill.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/filesystem' => 
    array (
      'packageKey' => 'symfony.filesystem',
      'packagePath' => 'Libraries/symfony/filesystem/',
      'composerName' => 'symfony/filesystem',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\Filesystem\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'friendsofphp/proxy-manager-lts' => 
    array (
      'packageKey' => 'friendsofphp.proxymanagerlts',
      'packagePath' => 'Libraries/friendsofphp/proxy-manager-lts/',
      'composerName' => 'friendsofphp/proxy-manager-lts',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'ProxyManager\\' => 'src/ProxyManager',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/stopwatch' => 
    array (
      'packageKey' => 'symfony.stopwatch',
      'packagePath' => 'Libraries/symfony/stopwatch/',
      'composerName' => 'symfony/stopwatch',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\Stopwatch\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/migrations' => 
    array (
      'packageKey' => 'doctrine.migrations',
      'packagePath' => 'Libraries/doctrine/migrations/',
      'composerName' => 'doctrine/migrations',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Migrations\\' => 'lib/Doctrine/Migrations',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'doctrine/annotations' => 
    array (
      'packageKey' => 'doctrine.annotations',
      'packagePath' => 'Libraries/doctrine/annotations/',
      'composerName' => 'doctrine/annotations',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Doctrine\\Common\\Annotations\\' => 'lib/Doctrine/Common/Annotations',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/yaml' => 
    array (
      'packageKey' => 'symfony.yaml',
      'packagePath' => 'Libraries/symfony/yaml/',
      'composerName' => 'symfony/yaml',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\Yaml\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/dom-crawler' => 
    array (
      'packageKey' => 'symfony.domcrawler',
      'packagePath' => 'Libraries/symfony/dom-crawler/',
      'composerName' => 'symfony/dom-crawler',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\DomCrawler\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/composer-plugin' => 
    array (
      'packageKey' => 'neos.composerplugin',
      'packagePath' => 'Libraries/neos/composer-plugin/',
      'composerName' => 'neos/composer-plugin',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\ComposerPlugin\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'composer/ca-bundle' => 
    array (
      'packageKey' => 'composer.cabundle',
      'packagePath' => 'Libraries/composer/ca-bundle/',
      'composerName' => 'composer/ca-bundle',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Composer\\CaBundle\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'composer/metadata-minifier' => 
    array (
      'packageKey' => 'composer.metadataminifier',
      'packagePath' => 'Libraries/composer/metadata-minifier/',
      'composerName' => 'composer/metadata-minifier',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Composer\\MetadataMinifier\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'composer/semver' => 
    array (
      'packageKey' => 'composer.semver',
      'packagePath' => 'Libraries/composer/semver/',
      'composerName' => 'composer/semver',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Composer\\Semver\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'composer/spdx-licenses' => 
    array (
      'packageKey' => 'composer.spdxlicenses',
      'packagePath' => 'Libraries/composer/spdx-licenses/',
      'composerName' => 'composer/spdx-licenses',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Composer\\Spdx\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'composer/pcre' => 
    array (
      'packageKey' => 'composer.pcre',
      'packagePath' => 'Libraries/composer/pcre/',
      'composerName' => 'composer/pcre',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Composer\\Pcre\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'composer/xdebug-handler' => 
    array (
      'packageKey' => 'composer.xdebughandler',
      'packagePath' => 'Libraries/composer/xdebug-handler/',
      'composerName' => 'composer/xdebug-handler',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Composer\\XdebugHandler\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'justinrainbow/json-schema' => 
    array (
      'packageKey' => 'justinrainbow.jsonschema',
      'packagePath' => 'Libraries/justinrainbow/json-schema/',
      'composerName' => 'justinrainbow/json-schema',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'JsonSchema\\' => 'src/JsonSchema/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'seld/jsonlint' => 
    array (
      'packageKey' => 'seld.jsonlint',
      'packagePath' => 'Libraries/seld/jsonlint/',
      'composerName' => 'seld/jsonlint',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Seld\\JsonLint\\' => 'src/Seld/JsonLint/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'seld/phar-utils' => 
    array (
      'packageKey' => 'seld.pharutils',
      'packagePath' => 'Libraries/seld/phar-utils/',
      'composerName' => 'seld/phar-utils',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Seld\\PharUtils\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/finder' => 
    array (
      'packageKey' => 'symfony.finder',
      'packagePath' => 'Libraries/symfony/finder/',
      'composerName' => 'symfony/finder',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\Finder\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/process' => 
    array (
      'packageKey' => 'symfony.process',
      'packagePath' => 'Libraries/symfony/process/',
      'composerName' => 'symfony/process',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\Process\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'react/promise' => 
    array (
      'packageKey' => 'react.promise',
      'packagePath' => 'Libraries/react/promise/',
      'composerName' => 'react/promise',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'React\\Promise\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/functions_include.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'composer/composer' => 
    array (
      'packageKey' => 'composer.composer',
      'packagePath' => 'Libraries/composer/composer/',
      'composerName' => 'composer/composer',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Composer\\' => 'src/Composer',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/polyfill-intl-idn' => 
    array (
      'packageKey' => 'symfony.polyfillintlidn',
      'packagePath' => 'Libraries/symfony/polyfill-intl-idn/',
      'composerName' => 'symfony/polyfill-intl-idn',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Polyfill\\Intl\\Idn\\' => '',
        ),
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'egulias/email-validator' => 
    array (
      'packageKey' => 'egulias.emailvalidator',
      'packagePath' => 'Libraries/egulias/email-validator/',
      'composerName' => 'egulias/email-validator',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Egulias\\EmailValidator\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'typo3fluid/fluid' => 
    array (
      'packageKey' => 'typo3fluid.fluid',
      'packagePath' => 'Libraries/typo3fluid/fluid/',
      'composerName' => 'typo3fluid/fluid',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'TYPO3Fluid\\Fluid\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/diff' => 
    array (
      'packageKey' => 'Neos.Diff',
      'packagePath' => 'Application/Neos.Diff/',
      'composerName' => 'neos/diff',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Diff\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'imagine/imagine' => 
    array (
      'packageKey' => 'imagine.imagine',
      'packagePath' => 'Libraries/imagine/imagine/',
      'composerName' => 'imagine/imagine',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Imagine\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'behat/transliterator' => 
    array (
      'packageKey' => 'behat.transliterator',
      'packagePath' => 'Libraries/behat/transliterator/',
      'composerName' => 'behat/transliterator',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Behat\\Transliterator\\' => 'src/Behat/Transliterator',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/cache-contracts' => 
    array (
      'packageKey' => 'symfony.cachecontracts',
      'packagePath' => 'Libraries/symfony/cache-contracts/',
      'composerName' => 'symfony/cache-contracts',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Contracts\\Cache\\' => '',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/var-exporter' => 
    array (
      'packageKey' => 'symfony.varexporter',
      'packagePath' => 'Libraries/symfony/var-exporter/',
      'composerName' => 'symfony/var-exporter',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\VarExporter\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/cache' => 
    array (
      'packageKey' => 'symfony.cache',
      'packagePath' => 'Libraries/symfony/cache/',
      'composerName' => 'symfony/cache',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\Cache\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'gedmo/doctrine-extensions' => 
    array (
      'packageKey' => 'gedmo.doctrineextensions',
      'packagePath' => 'Libraries/gedmo/doctrine-extensions/',
      'composerName' => 'gedmo/doctrine-extensions',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Gedmo\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/eel' => 
    array (
      'packageKey' => 'Neos.Eel',
      'packagePath' => 'Framework/Neos.Eel/',
      'composerName' => 'neos/eel',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Eel\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Eel\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
      'error-sorting-limit-reached' => true,
    ),
    'neos/flow' => 
    array (
      'packageKey' => 'Neos.Flow',
      'packagePath' => 'Framework/Neos.Flow/',
      'composerName' => 'neos/flow',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Flow\\' => 'Classes',
          'Neos\\Flow\\Core\\Migrations\\' => 'Scripts/Migrations',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'neos/fluid-adaptor' => 
    array (
      'packageKey' => 'Neos.FluidAdaptor',
      'packagePath' => 'Framework/Neos.FluidAdaptor/',
      'composerName' => 'neos/fluid-adaptor',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\FluidAdaptor\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\FluidAdaptor\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'neos/fusion' => 
    array (
      'packageKey' => 'Neos.Fusion',
      'packagePath' => 'Application/Neos.Fusion/',
      'composerName' => 'neos/fusion',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Fusion\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Fusion\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'neos/fusion-afx' => 
    array (
      'packageKey' => 'Neos.Fusion.Afx',
      'packagePath' => 'Application/Neos.Fusion.Afx/',
      'composerName' => 'neos/fusion-afx',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Fusion\\Afx\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/fusion-form' => 
    array (
      'packageKey' => 'Neos.Fusion.Form',
      'packagePath' => 'Application/Neos.Fusion.Form/',
      'composerName' => 'neos/fusion-form',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Fusion\\Form\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/imagine' => 
    array (
      'packageKey' => 'Neos.Imagine',
      'packagePath' => 'Application/Neos.Imagine/',
      'composerName' => 'neos/imagine',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Imagine\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/media' => 
    array (
      'packageKey' => 'Neos.Media',
      'packagePath' => 'Application/Neos.Media/',
      'composerName' => 'neos/media',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Media\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Media\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'neos/content-repository' => 
    array (
      'packageKey' => 'Neos.ContentRepository',
      'packagePath' => 'Application/Neos.ContentRepository/',
      'composerName' => 'neos/content-repository',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\ContentRepository\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\ContentRepository\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'neos/party' => 
    array (
      'packageKey' => 'Neos.Party',
      'packagePath' => 'Application/Neos.Party/',
      'composerName' => 'neos/party',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Party\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/twitter-bootstrap' => 
    array (
      'packageKey' => 'Neos.Twitter.Bootstrap',
      'packagePath' => 'Application/Neos.Twitter.Bootstrap/',
      'composerName' => 'neos/twitter-bootstrap',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Twitter\\Bootstrap\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/neos-ui-compiled' => 
    array (
      'packageKey' => 'Neos.Neos.Ui.Compiled',
      'packagePath' => 'Application/Neos.Neos.Ui.Compiled/',
      'composerName' => 'neos/neos-ui-compiled',
      'autoloadConfiguration' => 
      array (
        'psr-0' => 
        array (
          'Neos\\Neos\\Ui\\Compiled' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/polyfill-iconv' => 
    array (
      'packageKey' => 'symfony.polyfilliconv',
      'packagePath' => 'Libraries/symfony/polyfill-iconv/',
      'composerName' => 'symfony/polyfill-iconv',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Polyfill\\Iconv\\' => '',
        ),
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'swiftmailer/swiftmailer' => 
    array (
      'packageKey' => 'swiftmailer.swiftmailer',
      'packagePath' => 'Libraries/swiftmailer/swiftmailer/',
      'composerName' => 'swiftmailer/swiftmailer',
      'autoloadConfiguration' => 
      array (
        'files' => 
        array (
          0 => 'lib/swift_required.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/swiftmailer' => 
    array (
      'packageKey' => 'Neos.SwiftMailer',
      'packagePath' => 'Application/Neos.SwiftMailer/',
      'composerName' => 'neos/swiftmailer',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\SwiftMailer\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'league/csv' => 
    array (
      'packageKey' => 'league.csv',
      'packagePath' => 'Libraries/league/csv/',
      'composerName' => 'league/csv',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'League\\Csv\\' => 'src',
        ),
        'files' => 
        array (
          0 => 'src/functions_include.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/redirecthandler' => 
    array (
      'packageKey' => 'Neos.RedirectHandler',
      'packagePath' => 'Application/Neos.RedirectHandler/',
      'composerName' => 'neos/redirecthandler',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\RedirectHandler\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/redirecthandler-databasestorage' => 
    array (
      'packageKey' => 'Neos.RedirectHandler.DatabaseStorage',
      'packagePath' => 'Application/Neos.RedirectHandler.DatabaseStorage/',
      'composerName' => 'neos/redirecthandler-databasestorage',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\RedirectHandler\\DatabaseStorage\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/content-repository-dimensionspace' => 
    array (
      'packageKey' => 'Neos.ContentRepository.DimensionSpace',
      'packagePath' => 'Application/Neos.ContentRepository.DimensionSpace/',
      'composerName' => 'neos/content-repository-dimensionspace',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\ContentRepository\\DimensionSpace\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'flowpack/elasticsearch' => 
    array (
      'packageKey' => 'Flowpack.ElasticSearch',
      'packagePath' => 'Application/Flowpack.ElasticSearch/',
      'composerName' => 'flowpack/elasticsearch',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Flowpack\\ElasticSearch\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Flowpack\\ElasticSearch\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'neos/content-repository-search' => 
    array (
      'packageKey' => 'Neos.ContentRepository.Search',
      'packagePath' => 'Application/Neos.ContentRepository.Search/',
      'composerName' => 'neos/content-repository-search',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\ContentRepository\\Search\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\ContentRepository\\Search\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'flowpack/elasticsearch-contentrepositoryadaptor' => 
    array (
      'packageKey' => 'Flowpack.ElasticSearch.ContentRepositoryAdaptor',
      'packagePath' => 'Application/Flowpack.ElasticSearch.ContentRepositoryAdaptor/',
      'composerName' => 'flowpack/elasticsearch-contentrepositoryadaptor',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Flowpack\\ElasticSearch\\ContentRepositoryAdaptor\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/klarschiff' => 
    array (
      'packageKey' => 'Sitegeist.KlarSchiff',
      'packagePath' => 'Application/Sitegeist.KlarSchiff/',
      'composerName' => 'sitegeist/klarschiff',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\KlarSchiff\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/csvpo' => 
    array (
      'packageKey' => 'Sitegeist.CsvPO',
      'packagePath' => 'Application/Sitegeist.CsvPO/',
      'composerName' => 'sitegeist/csvpo',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\CsvPO\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Sitegeist\\CsvPO\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'sitegeist/stampede' => 
    array (
      'packageKey' => 'Sitegeist.Stampede',
      'packagePath' => 'Application/Sitegeist.Stampede/',
      'composerName' => 'sitegeist/stampede',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\Stampede\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'myclabs/php-enum' => 
    array (
      'packageKey' => 'myclabs.phpenum',
      'packagePath' => 'Libraries/myclabs/php-enum/',
      'composerName' => 'myclabs/php-enum',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'MyCLabs\\Enum\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'neos/media-browser' => 
    array (
      'packageKey' => 'Neos.Media.Browser',
      'packagePath' => 'Application/Neos.Media.Browser/',
      'composerName' => 'neos/media-browser',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Media\\Browser\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
      'error-sorting-limit-reached' => true,
    ),
    'neos/neos' => 
    array (
      'packageKey' => 'Neos.Neos',
      'packagePath' => 'Application/Neos.Neos/',
      'composerName' => 'neos/neos',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Neos\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Neos\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'neos/seo' => 
    array (
      'packageKey' => 'Neos.Seo',
      'packagePath' => 'Application/Neos.Seo/',
      'composerName' => 'neos/seo',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Seo\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/redirecthandler-ui' => 
    array (
      'packageKey' => 'Neos.RedirectHandler.Ui',
      'packagePath' => 'Application/Neos.RedirectHandler.Ui/',
      'composerName' => 'neos/redirecthandler-ui',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\RedirectHandler\\Ui\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/redirecthandler-neosadapter' => 
    array (
      'packageKey' => 'Neos.RedirectHandler.NeosAdapter',
      'packagePath' => 'Application/Neos.RedirectHandler.NeosAdapter/',
      'composerName' => 'neos/redirecthandler-neosadapter',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\RedirectHandler\\NeosAdapter\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\RedirectHandler\\NeosAdapter\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'sitegeist/kaleidoscope' => 
    array (
      'packageKey' => 'Sitegeist.Kaleidoscope',
      'packagePath' => 'Application/Sitegeist.Kaleidoscope/',
      'composerName' => 'sitegeist/kaleidoscope',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\Kaleidoscope\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'packagefactory/atomicfusion-presentationobjects' => 
    array (
      'packageKey' => 'PackageFactory.AtomicFusion.PresentationObjects',
      'packagePath' => 'Application/PackageFactory.AtomicFusion.PresentationObjects/',
      'composerName' => 'packagefactory/atomicfusion-presentationobjects',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'PackageFactory\\AtomicFusion\\PresentationObjects\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/neos-ui' => 
    array (
      'packageKey' => 'Neos.Neos.Ui',
      'packagePath' => 'Application/Neos.Neos.Ui/',
      'composerName' => 'neos/neos-ui',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Neos\\Ui\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'flowpack/nodetemplates' => 
    array (
      'packageKey' => 'Flowpack.NodeTemplates',
      'packagePath' => 'Application/Flowpack.NodeTemplates/',
      'composerName' => 'flowpack/nodetemplates',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Flowpack\\NodeTemplates\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/monocle' => 
    array (
      'packageKey' => 'Sitegeist.Monocle',
      'packagePath' => 'Plugins/Sitegeist.Monocle/',
      'composerName' => 'sitegeist/monocle',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\Monocle\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Sitegeist\\Monocle\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'sitegeist/lazybones' => 
    array (
      'packageKey' => 'Sitegeist.Lazybones',
      'packagePath' => 'Application/Sitegeist.Lazybones/',
      'composerName' => 'sitegeist/lazybones',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\Lazybones\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/archaeopteryx' => 
    array (
      'packageKey' => 'Sitegeist.Archaeopteryx',
      'packagePath' => 'Plugins/Sitegeist.Archaeopteryx/',
      'composerName' => 'sitegeist/archaeopteryx',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\Archaeopteryx\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/inspectorgadget' => 
    array (
      'packageKey' => 'Sitegeist.InspectorGadget',
      'packagePath' => 'Plugins/Sitegeist.InspectorGadget/',
      'composerName' => 'sitegeist/inspectorgadget',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\InspectorGadget\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/bitzer' => 
    array (
      'packageKey' => 'Sitegeist.Bitzer',
      'packagePath' => 'Application/Sitegeist.Bitzer/',
      'composerName' => 'sitegeist/bitzer',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\Bitzer\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/bitzer-approval' => 
    array (
      'packageKey' => 'Sitegeist.Bitzer.Approval',
      'packagePath' => 'Application/Sitegeist.Bitzer.Approval/',
      'composerName' => 'sitegeist/bitzer-approval',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\Bitzer\\Approval\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Sitegeist\\Bitzer\\Approval\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'sitegeist/lostintranslation' => 
    array (
      'packageKey' => 'Sitegeist.LostInTranslation',
      'packagePath' => 'Application/Sitegeist.LostInTranslation/',
      'composerName' => 'sitegeist/lostintranslation',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\LostInTranslation\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Sitegeist\\LostInTranslation\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'myclabs/deep-copy' => 
    array (
      'packageKey' => 'myclabs.deepcopy',
      'packagePath' => 'Libraries/myclabs/deep-copy/',
      'composerName' => 'myclabs/deep-copy',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'DeepCopy\\' => 'src/DeepCopy/',
        ),
        'files' => 
        array (
          0 => 'src/DeepCopy/deep_copy.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'hoerbiger/shared' => 
    array (
      'packageKey' => 'Hoerbiger.Shared',
      'packagePath' => 'Hoerbiger/Hoerbiger.Shared/',
      'composerName' => 'hoerbiger/shared',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Hoerbiger\\Shared\\' => 'Classes/',
          'Hoerbiger\\Shared\\Presentation\\' => 'Resources/Private/Fusion/Presentation/',
          'Hoerbiger\\Shared\\Integration\\' => 'Resources/Private/Fusion/Integration/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Hoerbiger\\Shared\\Package',
        'pathAndFilename' => 'Classes/Package.php',
      ),
    ),
    'hoerbiger/hoerbigercom' => 
    array (
      'packageKey' => 'Hoerbiger.HoerbigerCom',
      'packagePath' => 'Sites/Hoerbiger.HoerbigerCom/',
      'composerName' => 'hoerbiger/hoerbigercom',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Hoerbiger\\HoerbigerCom\\' => 'Classes/',
          'Hoerbiger\\HoerbigerCom\\Presentation\\' => 'Resources/Private/Fusion/Presentation/',
          'Hoerbiger\\HoerbigerCom\\Integration\\' => 'Resources/Private/Fusion/Integration/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'guzzlehttp/promises' => 
    array (
      'packageKey' => 'guzzlehttp.promises',
      'packagePath' => 'Libraries/guzzlehttp/promises/',
      'composerName' => 'guzzlehttp/promises',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'GuzzleHttp\\Promise\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/functions_include.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'psr/http-client' => 
    array (
      'packageKey' => 'psr.httpclient',
      'packagePath' => 'Libraries/psr/http-client/',
      'composerName' => 'psr/http-client',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Psr\\Http\\Client\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'guzzlehttp/guzzle' => 
    array (
      'packageKey' => 'guzzlehttp.guzzle',
      'packagePath' => 'Libraries/guzzlehttp/guzzle/',
      'composerName' => 'guzzlehttp/guzzle',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'GuzzleHttp\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/functions_include.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/object-reflector' => 
    array (
      'packageKey' => 'sebastian.objectreflector',
      'packagePath' => 'Libraries/sebastian/object-reflector/',
      'composerName' => 'sebastian/object-reflector',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/environment' => 
    array (
      'packageKey' => 'sebastian.environment',
      'packagePath' => 'Libraries/sebastian/environment/',
      'composerName' => 'sebastian/environment',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/recursion-context' => 
    array (
      'packageKey' => 'sebastian.recursioncontext',
      'packagePath' => 'Libraries/sebastian/recursion-context/',
      'composerName' => 'sebastian/recursion-context',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/object-enumerator' => 
    array (
      'packageKey' => 'sebastian.objectenumerator',
      'packagePath' => 'Libraries/sebastian/object-enumerator/',
      'composerName' => 'sebastian/object-enumerator',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/version' => 
    array (
      'packageKey' => 'sebastian.version',
      'packagePath' => 'Libraries/sebastian/version/',
      'composerName' => 'sebastian/version',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/cli-parser' => 
    array (
      'packageKey' => 'sebastian.cliparser',
      'packagePath' => 'Libraries/sebastian/cli-parser/',
      'composerName' => 'sebastian/cli-parser',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/diff' => 
    array (
      'packageKey' => 'sebastian.diff',
      'packagePath' => 'Libraries/sebastian/diff/',
      'composerName' => 'sebastian/diff',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/code-unit-reverse-lookup' => 
    array (
      'packageKey' => 'sebastian.codeunitreverselookup',
      'packagePath' => 'Libraries/sebastian/code-unit-reverse-lookup/',
      'composerName' => 'sebastian/code-unit-reverse-lookup',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/global-state' => 
    array (
      'packageKey' => 'sebastian.globalstate',
      'packagePath' => 'Libraries/sebastian/global-state/',
      'composerName' => 'sebastian/global-state',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/exporter' => 
    array (
      'packageKey' => 'sebastian.exporter',
      'packagePath' => 'Libraries/sebastian/exporter/',
      'composerName' => 'sebastian/exporter',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'nikic/php-parser' => 
    array (
      'packageKey' => 'nikic.phpparser',
      'packagePath' => 'Libraries/nikic/php-parser/',
      'composerName' => 'nikic/php-parser',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'PhpParser\\' => 'lib/PhpParser',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/lines-of-code' => 
    array (
      'packageKey' => 'sebastian.linesofcode',
      'packagePath' => 'Libraries/sebastian/lines-of-code/',
      'composerName' => 'sebastian/lines-of-code',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/resource-operations' => 
    array (
      'packageKey' => 'sebastian.resourceoperations',
      'packagePath' => 'Libraries/sebastian/resource-operations/',
      'composerName' => 'sebastian/resource-operations',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/type' => 
    array (
      'packageKey' => 'sebastian.type',
      'packagePath' => 'Libraries/sebastian/type/',
      'composerName' => 'sebastian/type',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/comparator' => 
    array (
      'packageKey' => 'sebastian.comparator',
      'packagePath' => 'Libraries/sebastian/comparator/',
      'composerName' => 'sebastian/comparator',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/code-unit' => 
    array (
      'packageKey' => 'sebastian.codeunit',
      'packagePath' => 'Libraries/sebastian/code-unit/',
      'composerName' => 'sebastian/code-unit',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sebastian/complexity' => 
    array (
      'packageKey' => 'sebastian.complexity',
      'packagePath' => 'Libraries/sebastian/complexity/',
      'composerName' => 'sebastian/complexity',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'deployer/phar-update' => 
    array (
      'packageKey' => 'deployer.pharupdate',
      'packagePath' => 'Libraries/deployer/phar-update/',
      'composerName' => 'deployer/phar-update',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Deployer\\Component\\PharUpdate\\' => 'src/',
          'Deployer\\Component\\PHPUnit\\' => 'src/PHPUnit/',
          'Deployer\\Component\\Version\\' => 'src/Version/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'pimple/pimple' => 
    array (
      'packageKey' => 'pimple.pimple',
      'packagePath' => 'Libraries/pimple/pimple/',
      'composerName' => 'pimple/pimple',
      'autoloadConfiguration' => 
      array (
        'psr-0' => 
        array (
          'Pimple' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'deployer/deployer' => 
    array (
      'packageKey' => 'deployer.deployer',
      'packagePath' => 'Libraries/deployer/deployer/',
      'composerName' => 'deployer/deployer',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Deployer\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/Support/helpers.php',
          1 => 'src/functions.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phar-io/version' => 
    array (
      'packageKey' => 'phario.version',
      'packagePath' => 'Libraries/phar-io/version/',
      'composerName' => 'phar-io/version',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phar-io/manifest' => 
    array (
      'packageKey' => 'phario.manifest',
      'packagePath' => 'Libraries/phar-io/manifest/',
      'composerName' => 'phar-io/manifest',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpunit/php-timer' => 
    array (
      'packageKey' => 'phpunit.phptimer',
      'packagePath' => 'Libraries/phpunit/php-timer/',
      'composerName' => 'phpunit/php-timer',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpunit/php-text-template' => 
    array (
      'packageKey' => 'phpunit.phptexttemplate',
      'packagePath' => 'Libraries/phpunit/php-text-template/',
      'composerName' => 'phpunit/php-text-template',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpunit/php-file-iterator' => 
    array (
      'packageKey' => 'phpunit.phpfileiterator',
      'packagePath' => 'Libraries/phpunit/php-file-iterator/',
      'composerName' => 'phpunit/php-file-iterator',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'theseer/tokenizer' => 
    array (
      'packageKey' => 'theseer.tokenizer',
      'packagePath' => 'Libraries/theseer/tokenizer/',
      'composerName' => 'theseer/tokenizer',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpunit/php-code-coverage' => 
    array (
      'packageKey' => 'phpunit.phpcodecoverage',
      'packagePath' => 'Libraries/phpunit/php-code-coverage/',
      'composerName' => 'phpunit/php-code-coverage',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpunit/php-invoker' => 
    array (
      'packageKey' => 'phpunit.phpinvoker',
      'packagePath' => 'Libraries/phpunit/php-invoker/',
      'composerName' => 'phpunit/php-invoker',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpdocumentor/reflection-common' => 
    array (
      'packageKey' => 'phpdocumentor.reflectioncommon',
      'packagePath' => 'Libraries/phpdocumentor/reflection-common/',
      'composerName' => 'phpdocumentor/reflection-common',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'phpDocumentor\\Reflection\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpdocumentor/type-resolver' => 
    array (
      'packageKey' => 'phpdocumentor.typeresolver',
      'packagePath' => 'Libraries/phpdocumentor/type-resolver/',
      'composerName' => 'phpdocumentor/type-resolver',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'phpDocumentor\\Reflection\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'webmozart/assert' => 
    array (
      'packageKey' => 'webmozart.assert',
      'packagePath' => 'Libraries/webmozart/assert/',
      'composerName' => 'webmozart/assert',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Webmozart\\Assert\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpdocumentor/reflection-docblock' => 
    array (
      'packageKey' => 'phpdocumentor.reflectiondocblock',
      'packagePath' => 'Libraries/phpdocumentor/reflection-docblock/',
      'composerName' => 'phpdocumentor/reflection-docblock',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'phpDocumentor\\Reflection\\' => 'src',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpspec/prophecy' => 
    array (
      'packageKey' => 'phpspec.prophecy',
      'packagePath' => 'Libraries/phpspec/prophecy/',
      'composerName' => 'phpspec/prophecy',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Prophecy\\' => 'src/Prophecy',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpunit/phpunit' => 
    array (
      'packageKey' => 'phpunit.phpunit',
      'packagePath' => 'Libraries/phpunit/phpunit/',
      'composerName' => 'phpunit/phpunit',
      'autoloadConfiguration' => 
      array (
        'classmap' => 
        array (
          0 => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/Framework/Assert/Functions.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'squizlabs/php_codesniffer' => 
    array (
      'packageKey' => 'squizlabs.phpcodesniffer',
      'packagePath' => 'Libraries/squizlabs/php_codesniffer/',
      'composerName' => 'squizlabs/php_codesniffer',
      'autoloadConfiguration' => 
      array (
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'symfony/css-selector' => 
    array (
      'packageKey' => 'symfony.cssselector',
      'packagePath' => 'Libraries/symfony/css-selector/',
      'composerName' => 'symfony/css-selector',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Symfony\\Component\\CssSelector\\' => '',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/Tests/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'maennchen/zipstream-php' => 
    array (
      'packageKey' => 'maennchen.zipstreamphp',
      'packagePath' => 'Libraries/maennchen/zipstream-php/',
      'composerName' => 'maennchen/zipstream-php',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'ZipStream\\' => 'src/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'ezyang/htmlpurifier' => 
    array (
      'packageKey' => 'ezyang.htmlpurifier',
      'packagePath' => 'Libraries/ezyang/htmlpurifier/',
      'composerName' => 'ezyang/htmlpurifier',
      'autoloadConfiguration' => 
      array (
        'psr-0' => 
        array (
          'HTMLPurifier' => 'library/',
        ),
        'files' => 
        array (
          0 => 'library/HTMLPurifier.composer.php',
        ),
        'exclude-from-classmap' => 
        array (
          0 => '/library/HTMLPurifier/Language/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'markbaker/complex' => 
    array (
      'packageKey' => 'markbaker.complex',
      'packagePath' => 'Libraries/markbaker/complex/',
      'composerName' => 'markbaker/complex',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Complex\\' => 'classes/src/',
        ),
        'files' => 
        array (
          0 => 'classes/src/functions/abs.php',
          1 => 'classes/src/functions/acos.php',
          2 => 'classes/src/functions/acosh.php',
          3 => 'classes/src/functions/acot.php',
          4 => 'classes/src/functions/acoth.php',
          5 => 'classes/src/functions/acsc.php',
          6 => 'classes/src/functions/acsch.php',
          7 => 'classes/src/functions/argument.php',
          8 => 'classes/src/functions/asec.php',
          9 => 'classes/src/functions/asech.php',
          10 => 'classes/src/functions/asin.php',
          11 => 'classes/src/functions/asinh.php',
          12 => 'classes/src/functions/atan.php',
          13 => 'classes/src/functions/atanh.php',
          14 => 'classes/src/functions/conjugate.php',
          15 => 'classes/src/functions/cos.php',
          16 => 'classes/src/functions/cosh.php',
          17 => 'classes/src/functions/cot.php',
          18 => 'classes/src/functions/coth.php',
          19 => 'classes/src/functions/csc.php',
          20 => 'classes/src/functions/csch.php',
          21 => 'classes/src/functions/exp.php',
          22 => 'classes/src/functions/inverse.php',
          23 => 'classes/src/functions/ln.php',
          24 => 'classes/src/functions/log2.php',
          25 => 'classes/src/functions/log10.php',
          26 => 'classes/src/functions/negative.php',
          27 => 'classes/src/functions/pow.php',
          28 => 'classes/src/functions/rho.php',
          29 => 'classes/src/functions/sec.php',
          30 => 'classes/src/functions/sech.php',
          31 => 'classes/src/functions/sin.php',
          32 => 'classes/src/functions/sinh.php',
          33 => 'classes/src/functions/sqrt.php',
          34 => 'classes/src/functions/tan.php',
          35 => 'classes/src/functions/tanh.php',
          36 => 'classes/src/functions/theta.php',
          37 => 'classes/src/operations/add.php',
          38 => 'classes/src/operations/subtract.php',
          39 => 'classes/src/operations/multiply.php',
          40 => 'classes/src/operations/divideby.php',
          41 => 'classes/src/operations/divideinto.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'markbaker/matrix' => 
    array (
      'packageKey' => 'markbaker.matrix',
      'packagePath' => 'Libraries/markbaker/matrix/',
      'composerName' => 'markbaker/matrix',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Matrix\\' => 'classes/src/',
        ),
        'files' => 
        array (
          0 => 'classes/src/Functions/adjoint.php',
          1 => 'classes/src/Functions/antidiagonal.php',
          2 => 'classes/src/Functions/cofactors.php',
          3 => 'classes/src/Functions/determinant.php',
          4 => 'classes/src/Functions/diagonal.php',
          5 => 'classes/src/Functions/identity.php',
          6 => 'classes/src/Functions/inverse.php',
          7 => 'classes/src/Functions/minors.php',
          8 => 'classes/src/Functions/trace.php',
          9 => 'classes/src/Functions/transpose.php',
          10 => 'classes/src/Operations/add.php',
          11 => 'classes/src/Operations/directsum.php',
          12 => 'classes/src/Operations/subtract.php',
          13 => 'classes/src/Operations/multiply.php',
          14 => 'classes/src/Operations/divideby.php',
          15 => 'classes/src/Operations/divideinto.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpoffice/phpspreadsheet' => 
    array (
      'packageKey' => 'phpoffice.phpspreadsheet',
      'packagePath' => 'Libraries/phpoffice/phpspreadsheet/',
      'composerName' => 'phpoffice/phpspreadsheet',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'PhpOffice\\PhpSpreadsheet\\' => 'src/PhpSpreadsheet',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'mikey179/vfsstream' => 
    array (
      'packageKey' => 'org.bovigo.vfs',
      'packagePath' => 'Libraries/mikey179/vfsstream/',
      'composerName' => 'mikey179/vfsstream',
      'autoloadConfiguration' => 
      array (
        'psr-0' => 
        array (
          'org\\bovigo\\vfs\\' => 'src/main/php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'editorconfig-checker/editorconfig-checker' => 
    array (
      'packageKey' => 'editorconfigchecker.editorconfigchecker',
      'packagePath' => 'Libraries/editorconfig-checker/editorconfig-checker/',
      'composerName' => 'editorconfig-checker/editorconfig-checker',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'EditorconfigChecker\\' => 'src/EditorconfigChecker',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'phpstan/phpstan' => 
    array (
      'packageKey' => 'phpstan.phpstan',
      'packagePath' => 'Libraries/phpstan/phpstan/',
      'composerName' => 'phpstan/phpstan',
      'autoloadConfiguration' => 
      array (
        'files' => 
        array (
          0 => 'bootstrap.php',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\GenericPackage',
        'pathAndFilename' => '',
      ),
    ),
    'sitegeist/magicwand' => 
    array (
      'packageKey' => 'Sitegeist.MagicWand',
      'packagePath' => 'Application/Sitegeist.MagicWand/',
      'composerName' => 'sitegeist/magicwand',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Sitegeist\\MagicWand\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'neos/behat' => 
    array (
      'packageKey' => 'Neos.Behat',
      'packagePath' => 'Application/Neos.Behat/',
      'composerName' => 'neos/behat',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Neos\\Behat\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'internezzo/childreload' => 
    array (
      'packageKey' => 'Internezzo.ChildReload',
      'packagePath' => 'Application/Internezzo.ChildReload/',
      'composerName' => 'internezzo/childreload',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Internezzo\\ChildReload\\' => 'Classes/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'hoerbiger/hoerbigercom-pressarchive' => 
    array (
      'packageKey' => 'Hoerbiger.HoerbigerCom.PressArchive',
      'packagePath' => 'Hoerbiger/Hoerbiger.HoerbigerCom.PressArchive/',
      'composerName' => 'hoerbiger/hoerbigercom-pressarchive',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Hoerbiger\\HoerbigerCom\\PressArchive\\' => 'Classes/',
          'Hoerbiger\\HoerbigerCom\\PressArchive\\Presentation\\' => 'Resources/Private/Fusion/Presentation/',
          'Hoerbiger\\HoerbigerCom\\PressArchive\\Integration\\' => 'Resources/Private/Fusion/Integration/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'nezaniel/geographiclibrary' => 
    array (
      'packageKey' => 'Nezaniel.GeographicLibrary',
      'packagePath' => 'Nezaniel/Nezaniel.GeographicLibrary/',
      'composerName' => 'nezaniel/geographiclibrary',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Nezaniel\\GeographicLibrary\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'nezaniel/geographiclibrary-googlemapsadapter' => 
    array (
      'packageKey' => 'Nezaniel.GeographicLibrary.GoogleMapsAdapter',
      'packagePath' => 'Nezaniel/Nezaniel.GeographicLibrary.GoogleMapsAdapter/',
      'composerName' => 'nezaniel/geographiclibrary-googlemapsadapter',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Nezaniel\\GeographicLibrary\\GoogleMapsAdapter\\' => 'Classes',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'hoerbiger/hoerbigercom-affiliatedirectory' => 
    array (
      'packageKey' => 'Hoerbiger.HoerbigerCom.AffiliateDirectory',
      'packagePath' => 'Hoerbiger/Hoerbiger.HoerbigerCom.AffiliateDirectory/',
      'composerName' => 'hoerbiger/hoerbigercom-affiliatedirectory',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Hoerbiger\\HoerbigerCom\\AffiliateDirectory\\' => 'Classes/',
          'Hoerbiger\\HoerbigerCom\\AffiliateDirectory\\Presentation\\' => 'Resources/Private/Fusion/Presentation/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'hoerbiger/hoerbigercom-catalog' => 
    array (
      'packageKey' => 'Hoerbiger.HoerbigerCom.Catalog',
      'packagePath' => 'Hoerbiger/Hoerbiger.HoerbigerCom.Catalog/',
      'composerName' => 'hoerbiger/hoerbigercom-catalog',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Hoerbiger\\HoerbigerCom\\Catalog\\' => 'Classes/',
          'Hoerbiger\\HoerbigerCom\\Catalog\\Presentation\\' => 'Resources/Private/Fusion/Presentation/',
          'Hoerbiger\\HoerbigerCom\\Catalog\\Integration\\' => 'Resources/Private/Fusion/Integration/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'hoerbiger/hoerbigercom-application-worlds' => 
    array (
      'packageKey' => 'Hoerbiger.HoerbigerCom.ApplicationWorlds',
      'packagePath' => 'Hoerbiger/Hoerbiger.HoerbigerCom.ApplicationWorlds/',
      'composerName' => 'hoerbiger/hoerbigercom-application-worlds',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Hoerbiger\\HoerbigerCom\\ApplicationWorlds\\' => 'Classes/',
          'Hoerbiger\\HoerbigerCom\\ApplicationWorlds\\Presentation\\' => 'Resources/Private/Fusion/Presentation/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
    'hoerbiger/hoerbigercom-successstories' => 
    array (
      'packageKey' => 'Hoerbiger.HoerbigerCom.SuccessStories',
      'packagePath' => 'Hoerbiger/Hoerbiger.HoerbigerCom.SuccessStories/',
      'composerName' => 'hoerbiger/hoerbigercom-successstories',
      'autoloadConfiguration' => 
      array (
        'psr-4' => 
        array (
          'Hoerbiger\\HoerbigerCom\\SuccessStories\\' => 'Classes/',
          'Hoerbiger\\HoerbigerCom\\SuccessStories\\Presentation\\' => 'Resources/Private/Fusion/Presentation/',
          'Hoerbiger\\HoerbigerCom\\SuccessStories\\Integration\\' => 'Resources/Private/Fusion/Integration/',
        ),
      ),
      'packageClassInformation' => 
      array (
        'className' => 'Neos\\Flow\\Package\\Package',
        'pathAndFilename' => '',
      ),
    ),
  ),
  'version' => 6,
);